package com.example.phonebook;

public class Utils {

    public static final String EMAIL = "johaali043@gmail.com";
    public static final String PASSWORD = "Pleo_123";
}
